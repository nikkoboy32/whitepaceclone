<?php 
require_once 'controller/connect.php';
?>
<div class="sidebar f-left">
	<ul>
 		<li class="current" id="inbox"></li>
 		<li id="trash"><span>Trash</span></li>
 	</ul>
</div>