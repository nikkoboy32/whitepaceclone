	</div>
	<!--footer-->
	<div id="footer">		
		<ul>
			<li class="<?php echo $a;?>"><a href="index.php">Home</a></li>
			<li class="navspacer"></li>
			<li class="<?php echo $b;?>"><a href="javascript:;">Handbags</a></li>		
			<li class="navspacer"></li>
			<li class="<?php echo $c;?>"><a href="javascript:;">Jewelry</a></li>						
			<li class="navspacer"></li>
			<li class="<?php echo $d;?>"><a href="javascript:;">Accessories</a></li>		
			<li class="navspacer"></li>
			<li class="<?php echo $e;?>"><a href="javascript:;">Sale</a></li>
			<li class="navspacer"></li>
			<li class="<?php echo $f;?>"><a href="javascript:;">Brand</a></li>
			<li class="navspacer"></li>
			<li class="<?php echo $g;?>"><a href="javascript:;">Checkout</a></li>
			<li class="navspacer"></li>
			<li class="<?php echo $h;?>"><a href="contact-us.php">Contact Us</a></li>
		</ul>
		<div id="copyright">
			&copy; Copyright <?php echo (date('Y') == '2013') ? '2013' : '2013 - '.date('Y');?> <span>&bull;</span> <?php echo $compname; ?> <span>&bull;</span> <a target="_blank" href="http://www.proweaver.com/ecommerce-custom-web-design">Ecommerce Web Design</a>: <a target="_blank" href="http://www.proweaver.com">Proweaver</a>
		</div>	
	</div>
<!--end footer-->
</div>
<!--end wrapper-->
</body>
</html>
<!-- 
****************************************************************************
****************************************************************************
Author: control #
Date: July 18, 2013
****************************************************************************
****************************************************************************
-->
<?php exit; ?>